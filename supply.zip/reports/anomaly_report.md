# Anomaly Detection Report

Shipments analyzed (delivered only): 16,053
Statistical (per-category z-score, |z| > 3.0) outliers: 309
ML (Isolation Forest, contamination=0.02) anomalies: 322
**Combined anomalies flagged: 350**

## Validation against known injected anomalies
Precision: 83.1% | Recall: 99.0%
(TP=291, FP=59, FN=3, TN=15700)

## Top 15 anomalies (by ML anomaly score)

| Shipment | Supplier | Category | Qty | Unit Cost | Delay (days) | Score | Known? |
|---|---|---|---|---|---|---|---|
| SHP019503 | SUP022 | Raw Materials | 538,050 | $39.26 | -3 | 0.197 | yes |
| SHP005356 | SUP014 | Machinery Parts | 137 | $167.25 | 58 | 0.195 | yes |
| SHP012203 | SUP030 | Electronics Components | 643 | $16.45 | 56 | 0.180 | yes |
| SHP012059 | SUP027 | Electronics Components | 1,152 | $9.95 | 45 | 0.179 | yes |
| SHP017956 | SUP027 | Electronics Components | 650 | $15.24 | 52 | 0.177 | yes |
| SHP001193 | SUP025 | Textiles | 1,253 | $7.80 | 56 | 0.176 | yes |
| SHP016851 | SUP002 | Office Supplies | 2,033 | $2.70 | 59 | 0.175 | yes |
| SHP014524 | SUP014 | Machinery Parts | 206 | $112.95 | 59 | 0.175 | yes |
| SHP018270 | SUP012 | Machinery Parts | 140 | $95.79 | 63 | 0.174 | yes |
| SHP005618 | SUP022 | Raw Materials | 10,371 | $1.79 | 54 | 0.174 | yes |
| SHP018724 | SUP002 | Office Supplies | 757 | $4.62 | 58 | 0.173 | yes |
| SHP014398 | SUP031 | Textiles | 3,239 | $5.83 | 59 | 0.172 | yes |
| SHP017255 | SUP001 | Packaging | 8,830 | $0.83 | 69 | 0.171 | yes |
| SHP008432 | SUP008 | Office Supplies | 693 | $4.74 | 52 | 0.166 | yes |
| SHP001917 | SUP023 | Raw Materials | 4,549 | $1.80 | 60 | 0.166 | yes |

## Suppliers with the most flagged anomalies

| Supplier | Anomaly count |
|---|---|
| SUP007 | 31 |
| SUP023 | 15 |
| SUP025 | 15 |
| SUP003 | 13 |
| SUP006 | 13 |
| SUP038 | 13 |
| SUP040 | 12 |
| SUP001 | 12 |
| SUP031 | 11 |
| SUP009 | 11 |
