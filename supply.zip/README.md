# Supply Chain Analysis & Anomaly Detection System

Analyzes supplier and shipment data to calculate delivery performance (lead
times, delays, on-time rate) in SQL, then flags anomalous shipments with a
combination of statistical and machine-learning methods, surfaced through an
interactive analytics dashboard.

## Pipeline

```
generate_data.py            synthetic suppliers (reliability tiers A/B/C)
        |                   and shipments, with a small set of deliberately
        v                   injected delay/quantity/cost anomalies
data/raw/{suppliers,shipments}.csv
        |
        v
sql_analysis.py               SQL: lead time & delay per shipment, then
        |                      supplier / category / warehouse / monthly
        v                      performance rollups (all GROUP BY in SQL)
data/processed/{supplier,category,warehouse}_performance.csv, monthly_trend.csv
        |
        v
anomaly_detection.py            per-category z-scores (statistical) +
        |                        IsolationForest over those z-scores (ML),
        v                        validated against known injected anomalies
data/processed/shipments_with_anomalies.csv, reports/anomaly_report.md
        |
        v
build_dashboard.py                Plotly dashboard: KPIs, worst-performing
        v                          suppliers, delay trends, anomaly scatter
dashboard/supply_chain_dashboard.html
```

Run everything with `python -m src.pipeline`, or run any stage individually.

## Why these choices

- **Anomaly detection is checked against ground truth, not just eyeballed.**
  `generate_data.py` stamps an `injected_anomaly` flag on the handful of
  shipments it deliberately corrupts (extreme delay, quantity or unit cost).
  `anomaly_detection.py` never reads that flag while detecting — it's used
  purely afterward to compute a real precision/recall for the combined
  statistical + ML approach (currently ~83% precision, ~99% recall — see
  [reports/anomaly_report.md](reports/anomaly_report.md)).
- **Z-scores are computed per product category, not globally.** A quantity
  of 5,000 units is routine for Raw Materials and wildly anomalous for
  Machinery Parts; a single global z-score would just rediscover "which
  category is this," not which shipments are actually unusual.
- **Supplier tiers are calibrated so on-time rate actually separates them.**
  Tier A/B/C promised lead times carry a realistic SLA buffer, so Tier A
  clears its own promise ~90% of the time and Tier C only ~33% — a
  believable "a handful of underperforming suppliers are dragging down the
  average" story, which is what a supplier-performance dashboard exists to surface.
- **SQL = SQLite.** [sql/analysis_queries.sql](sql/analysis_queries.sql) uses
  SQLite's `julianday()` for date math; the MySQL equivalent
  (`DATEDIFF(...)`) is noted in the file header.
- **Tableau -> Plotly HTML.** Tableau Desktop isn't available in this
  environment, so the dashboard is a self-contained interactive HTML page
  covering the same ground: delivery performance, supplier trends and
  inventory/anomaly KPIs. Open it directly in a browser — no server needed.
  The anomaly scatter plot downsamples its "normal" point cloud to 2,000
  points (every flagged anomaly is kept) purely to keep the HTML file small
  — the full ~16k-point version renders identically but ships 5x more data.

## Tech stack

Python - Pandas - SQL (SQLite) - Scikit-learn (IsolationForest) - Plotly

## Setup

```bash
uv venv --python 3.12 .venv
uv pip install -p .venv/Scripts/python.exe -r requirements.txt
```

## Run

```bash
.venv/Scripts/python.exe -m src.pipeline
```

Then open [dashboard/supply_chain_dashboard.html](dashboard/supply_chain_dashboard.html) in a browser.

## Sample result

20,000 synthetic shipments across 40 suppliers, 2 years:

| Metric | Value |
|---|---|
| Overall on-time delivery rate | 67.0% |
| Tier A / B / C on-time rate | ~90% / ~65% / ~33% |
| Anomalies flagged (statistical + ML) | 350 |
| Detection precision / recall vs. known injected anomalies | 83.1% / 99.0% |

Full breakdown, top flagged shipments and worst-performing suppliers in
[reports/anomaly_report.md](reports/anomaly_report.md).

## Project structure

```
src/
  generate_data.py      synthetic suppliers + shipments generator
  sql_analysis.py         SQL performance rollups (SQLite)
  anomaly_detection.py      statistical + ML anomaly flagging
  build_dashboard.py          Plotly dashboard generator
  pipeline.py                   orchestrates all stages
sql/analysis_queries.sql   the performance-rollup SQL
dashboard/                  generated dashboard (committed as a sample)
reports/                     generated anomaly report (committed as a sample)
data/                          generated at runtime, gitignored
```
